const help1 = (prefix) => {

	return `
🇧🇷 
╭──────────────╮
 *COMANDOS EXTRAS*
╰──────────────╯ 
      

➸ Útil em : mandar imagens aleatórias de loli
➸ Uso : basta enviar o comando\n
➸ 「Comando」 : *${prefix}nsfwloli*
➸ Útil em : mandar imagens aleatórias de nsfw loli
➸ Uso : basta enviar o comando\n
➸ 「Comando」 : *${prefix}url2img*
➸ Útil em : tirar screenshots da web
➸ Uso : *${prefix}url2img [tipe] [url]*\n
➸ 「Comando」 : *${prefix}ocr*
➸ Útil em : pegar o texto da foto e lhe enviar
➸ Uso : responder imagem ou enviar mensagem com legenda\n
➸ 「Comando」 : *${prefix}wait*
➸ Útil em : pesquisar sobre o anime por imagem [ Que anime é este/que ]
➸ Uso : responder imagem ou enviar imagem com legenda\n

╭──────────────╮
 *GRUPOS*
╰──────────────╯ 
      
➸ 「Comando」 : *${prefix}linkgroup*
➸ Útil em : enviar o link do grupo
➸ Uso : basta enviar o comando\n
➸ 「Comando」 : *${prefix}marcar*
➸ Útil em : marcar todos os membros do grupo, incluindo administradores
➸ Uso : basta enviar o comando\n
➸ Nota : Você precisa ser administrador do grupo\n
➸ 「Comando」 : *${prefix}add*
➸ Útil em : adicionar membro ao grupo
➸ Uso : *${prefix}add 5585xxxxx*\n
➸ Nota : o bot precisa ser admin!\n
➸ 「Comando」 : *${prefix}kick*
➸ Útil em : remover membros do grupo
➸ Uso : *${prefix}kick e o @da pessoa*\n
➸ Nota : Você precisa ser admin e o bot também
➸ 「Comando」 : *${prefix}promote*
➸ Útil em : tornar membro do grupo um administrador
➸ Uso : *${prefix}promote e o @da pessoa*\n
➸ Nota : Você precisa ser admin e o bot também
➸ 「Comando」 : *${prefix}demote*
➸ Útil em : tornar o administrador um membro comum
➸ Uso : *${prefix}demote e o @da pessoa*\n
➸ Nota : Você precisa ser admin e o bot também

🇺🇸
╭──────────────╮
  * EXTRA COMMANDS *
╰──────────────╯

➸ Useful for: sending random images of loli
➸ Usage: just send the command\n
➸ 「Command」: *${prefix}nsfwloli*
➸ Useful for: sending random images of nsfw loli
➸ Usage: just send the command\n
➸ 「Command」: *${prefix}url2img*
➸ Useful in: taking screenshots from the web
➸ Usage: *${prefix} url2img [tipe] [url]*\n
➸ 「Command」: *${prefix}ocr*
➸ Useful for: take the text of the photo and send
➸ Usage: reply to image or send message with caption\n
➸ 「Command」: *${prefix}wait*
➸ Useful for: researching anime by image [ What anime is this/what ]
➸ Usage: reply image or send image with caption\n

╭──────────────╮
  * GROUPS *
╰──────────────╯

➸ 「Command」: *${prefix}linkgroup*
➸ Useful in: send group link
➸ Usage: just send the command\n
➸ 「Command」: *${prefix}marcar*
➸ Useful for: tagging all group members, including administrators
➸ Usage: just send the command\n
➸ Note: You must be a group administrator\n
➸ 「Command」: *${prefix}add*
➸ Useful for: adding members to the group
➸ Usage: *${prefix}add 5585xxxxx*\n
➸ Note: the bot must be admin!\N
➸ 「Command」: *${prefix}kick*
➸ Useful for: removing group members
➸ Usage: *${prefix} kick and @person's*\n
➸ Note: You need to be admin and the bot too
➸ 「Command」: *${prefix}promote*
➸ Useful in: making group member an administrator
➸ Usage: *${prefix} promote and @person's*\n
➸ Note: You need to be admin and the bot too
➸ 「Command」: *${prefix}demote*
➸ Useful for: making the administrator a common member
➸ Usage: *${prefix} demote and @person*\n
➸ Note: You need to be admin and the bot too

╔════════════════════
  SCRIPT FEITO POR *DARK*
  MODIFICADO POR *JOHNXINHA*
  DUVIDAS? Zap do Brabor 👇
  WA.me/5517991134416
╚════════════════════`

}
exports.help1 = help1

