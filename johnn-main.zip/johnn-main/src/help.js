const help = (prefix) => {
	return `

╔════════════════════
  *ꜱᴛɪᴄᴋᴇʀ ʙᴏᴛ*
╚════════════════════

➸ Prefix:  *「${prefix} 」*
➸ Status: *「 Online 」*

╔════════════════════
  ꜱᴛɪᴄᴋᴇʀꜱ👇 🇧🇷 / 🇺🇸
╚════════════════════

🇧🇷      
➸ 「Comando」 : *${prefix}sticker* ou *${prefix}stiker*
➸ Útil em : Converter imagem/gif/vídeo em adesivo.
➸ Uso : Mande uma imagem/gif/video com legenda ".sticker" ".stiker"
➸ 「Comando」 : *${prefix}toimg*
➸ Útil em : Converter adesivo em imagem.
➸ Uso : Responda o adesivo.

🇺🇸
➸ 「Command」: *${prefix}sticker* or *${prefix}stiker*
➸ It is useful in: Convert image/gif/video into sticker.
➸ Usage: Send an image/gif/video with the caption ".sticker" ".stiker"
➸ 「Command」: *${prefix}toimg*
➸ It is useful in: Convert sticker to image.
➸ Usage: Answer the sticker.

➸ *${prefix}help1* ♔
➸ Nota: 𝙈𝙚𝙣𝙪 𝙙𝙤 𝘿𝙖𝙧𝙠𝙯𝙚𝙧𝙖

➸ 🇧🇷 *NOTA: SE POR ACASO O BOT CAIR, NÃO SE PREOCUPE QUE VAMOS RESOLVER!*
➸ 🇺🇸 *NOTE: IF IN CASE THE BOT FALLS, DON'T WORRY THAT WE'LL SOLVE IT!*

╔════════════════════
  SCRIPT FEITO POR *DARK*
  MODIFICADO POR *JOHNXINHA*
  DUVIDAS? Zap do Brabor 👇
  WA.me/5517991134416
╚════════════════════

}

exports.help = help






