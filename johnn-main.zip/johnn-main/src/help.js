const help = (prefix) => {
	return `

		🐉♩  --------------------  🐒♢
			🌹𝘽𝙤𝙩 𝙙𝙤 𝙅𝙤𝙝𝙣𝙭𝙞𝙣𝙝𝙖🌹
		🐉♩  --------------------  🐒♢


➸ Prefixo:  *「${prefix} 」*
➸ Status: *「 Online 」*

       🐒 ──── 😳 ──── 🐒
		𝙁𝙞𝙜𝙪𝙧𝙞𝙣𝙝𝙖𝙨👇
       🐒 ──── 😳 ──── 🐒
      
➸ Comando : *${prefix}sticker* ou *${prefix}stiker*
➸ útil em : Converter imagem/gif/vídeo em adesivo.
➸ uso : Mande uma imagem/gif/video com legenda ".sticker" ".stiker"
➸ Comando : *${prefix}toimg*
➸ útil em : Converter adesivo em imagem.
➸ uso : Responda o adesivo.

       🐒 ──── 😳 ──── 🐒
		【﻿ｍｅｍｅｓ】👇
       🐒 ──── 😳 ──── 🐒
      
➸ Comando : *${prefix}meme*
➸ útil em : Ele manda memes aleatórios [inglês].
➸ uso : Basta enviar o comando\n
➸ Comando : *${prefix}memeindo*
➸ útil em : Ele manda vários memes [indo].
➸ uso : Só basta enviar o comando.

       🐒 ──── 😳 ──── 🐒
		𝙊𝙪𝙩𝙧𝙤𝙨👇
       🐒 ──── 😳 ──── 🐒
      
➸ Comando : *${prefix}url2img*
➸ útil em : Tirar screenshots da web.
➸ uso : *${prefix}url2img [tipe] [url]*\n
➸ Comando : *${prefix}ocr*
➸ útil em : Pegar o texto da foto e lhe enviar.
➸ uso : Responder imagem ou enviar mensagem com legenda\n
➸ Comando : *${prefix}wait*
➸ útil em : Pesquisar sobre o anime por imagem [ Que anime é este/que ].
➸ uso : Responder imagem ou enviar imagem com legenda\n

       🐒 ──── 😳 ──── 🐒
	𝙁𝙪𝙣çõ𝙚𝙨 𝙥𝙖𝙧𝙖 𝙜𝙧𝙪𝙥𝙤𝙨👇
       🐒 ──── 😳 ──── 🐒
      
➸ Comando : *${prefix}linkgroup*
➸ útil em : Enviar o link do grupo.
➸ uso : Basta enviar o comando\n
➸ Comando : *${prefix}marcar*
➸ útil em : Marcar todos os membros do grupo, incluindo *administradores*.
➸ uso : Basta enviar o comando\n
➸ Nota : Você precisa ser administrador do grupo\n
➸ Comando : *${prefix}simih*
➸ Nota : Você precisa ser administrador do grupo\n
➸ Comando : *${prefix}add*
➸ útil em : Adicionar membro ao grupo.
➸ uso : *${prefix}add 5585xxxxx*\n
➸ Nota : o bot precisa ser admin!\n
➸ Comando : *${prefix}kick*
➸ útil em : Remover membros do grupo.
➸ uso : *${prefix}kick e o @da pessoa*\n
➸ Nota : Você precisa ser admin e o bot também
➸ Comando : *${prefix}promote*
➸ útil em : Tornar membro do grupo um administrador.
➸ uso : *${prefix}promote e o @da pessoa*\n
➸ Nota : Você precisa ser admin e o bot também
➸ Comando : *${prefix}demote*
➸ útil em : Tornar o administrador um membro comum.
➸ uso : *${prefix}demote e o @da pessoa*\n
➸ Nota : Você precisa ser admin e o bot também

		🐉♩  --------------------  🐒♢
			  🌹𝙈𝙚𝙣𝙪 𝙙𝙤 𝙅𝙤𝙝𝙣𝙭𝙞𝙣𝙝𝙖🌹
		🐉♩  --------------------  🐒♢   

➸ *${prefix}help1* ♔
➸ Nota: 𝙈𝙚𝙣𝙪 𝙙𝙤 𝘿𝙖𝙧𝙠𝙯𝙚𝙧𝙖

➸ *NOTA: SE POR ACASO O BOT CAIR, NÃO SE PREOCUPE QUE VAMOS RESOLVER!*

╔════════════════════
  SCRIPT FEITO POR *DARK*
  MODIFICADO POR *JOHNXINHA*
  DUVIDAS? Zap do Brabor 👇
  WA.me/5517991134416
╚════════════════════`
}

exports.help = help






